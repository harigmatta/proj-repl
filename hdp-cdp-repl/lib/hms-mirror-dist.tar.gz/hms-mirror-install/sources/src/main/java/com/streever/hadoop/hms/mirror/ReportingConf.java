package com.streever.hadoop.hms.mirror;

import com.jcabi.manifests.Manifests;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReportingConf {
    public static final String CLEAR_CONSOLE = "\33[H\33[2J";
    public static final String RESET_TO_PREVIOUS_LINE = "\33[1A\33[2K";
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final int ANSI_SIZE = 5;

    public static String substituteVariablesFromManifest(String template) {
        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        Matcher matcher = pattern.matcher(template);
        // StringBuilder cannot be used here because Matcher expects StringBuffer
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String matchStr = matcher.group(1);
            try {
                String replacement = Manifests.read(matchStr);
                if (replacement != null) {
                    // quote to work properly with $ and {,} signs
                    matcher.appendReplacement(buffer, replacement != null ? Matcher.quoteReplacement(replacement) : "null");
                } else {
//                    System.out.println("No replacement found for: " + matchStr);
                }
            } catch (IllegalArgumentException iae) {
                //iae.printStackTrace();
                // Couldn't locate MANIFEST Entry.
                // Silently continue. Usually happens in IDE->run.
            }
        }
        matcher.appendTail(buffer);
        String rtn = buffer.toString();
        return rtn;
    }

    public static String substituteAllVariables(List<String> template, Map<String, String> varmap) {
        Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
        StringBuilder sb = new StringBuilder();

        for (String line: template) {
            Matcher matcher = pattern.matcher(line);
            // StringBuilder cannot be used here because Matcher expects StringBuffer
            StringBuffer buffer = new StringBuffer();
            while (matcher.find()) {
                String matchStr = matcher.group(1);
                try {
                    String replacement = Manifests.read(matchStr);
                    if (replacement != null) {
                        // quote to work properly with $ and {,} signs
                        matcher.appendReplacement(buffer, replacement != null ? Matcher.quoteReplacement(replacement) : "null");
                    }
                } catch (IllegalArgumentException iae) {
                    // Couldn't locate MANIFEST Entry.
                    // Silently continue. Usually happens in IDE->run.
                    String replacement = varmap.get(matchStr);
                    if (replacement != null)
                        matcher.appendReplacement(buffer, replacement != null ? Matcher.quoteReplacement(replacement) : "null");
                }
            }
            matcher.appendTail(buffer);
            sb.append(buffer.toString()).append("\n");
        }
        return sb.toString();
    }

}
