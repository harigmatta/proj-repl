package com.streever.hadoop.hms.mirror;

public enum CreateStrategy {
    NOTHING, CREATE, DROP, REPLACE, LEAVE;
}
