package com.streever.hadoop.hms.mirror;

public enum PathStrategy {
    DB, TABLE;
}
